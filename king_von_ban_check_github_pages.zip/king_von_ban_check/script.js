/*
 * King Von Ban Check — GitHub Pages demo
 * Important: GitHub Pages is static hosting. Never put private API keys here.
 * To connect a real provider, use a server-side proxy you control and an authorized API.
 */
"use strict";

const form = document.querySelector("#check-form");
const phoneInput = document.querySelector("#phone");
const formError = document.querySelector("#form-error");
const resultSection = document.querySelector("#result-section");
const resultCard = document.querySelector("#result-card");
const historyList = document.querySelector("#history-list");
const historyEmpty = document.querySelector("#history-empty");
const clearHistoryButton = document.querySelector("#clear-history");

const HISTORY_KEY = "kingVonBanCheckHistoryV1";
const MAX_HISTORY = 8;

function normalizePhone(raw) {
  // Keep only a leading plus and digits; reject ambiguous/local-only numbers.
  const trimmed = raw.trim();
  const hasPlus = trimmed.startsWith("+");
  const digits = trimmed.replace(/\D/g, "");
  if (!hasPlus || digits.length < 7 || digits.length > 15) return null;
  return "+" + digits;
}

function getHistory() {
  try {
    const value = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

function saveHistory(items) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, MAX_HISTORY)));
  } catch {
    // The checker still works if local storage is blocked or full.
  }
}

function formatTime(date = new Date()) {
  return new Intl.DateTimeFormat("fr-FR", {
    dateStyle: "short", timeStyle: "medium"
  }).format(date);
}

function showError(message) {
  formError.textContent = message;
  formError.hidden = false;
}

function hideError() {
  formError.textContent = "";
  formError.hidden = true;
}

function setText(id, value) {
  document.getElementById(id).textContent = value;
}

function renderResult(result) {
  resultSection.hidden = false;
  resultCard.classList.toggle("unknown", result.status === "unknown");
  setText("result-phone", result.phone);
  setText("result-summary", result.summary);
  setText("result-badge", result.statusLabel);
  setText("spam-value", result.spamReports);
  setText("ban-value", result.banStatus);
  setText("reason-value", result.reason);
  setText("time-value", result.checkedAt);
  setText("source-value", result.source);
  setText("result-disclaimer", result.disclaimer);
  document.querySelector(".result-icon").textContent = result.status === "unknown" ? "?" : "!";
  resultSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function makeDemoResult(phone) {
  // Deliberately does not infer a real ban from a phone number.
  return {
    phone,
    status: "unknown",
    statusLabel: "DEMO · UNKNOWN",
    summary: "Statut réel non vérifié",
    spamReports: "Non disponible",
    banStatus: "Inconnu",
    reason: "Aucune source réelle connectée",
    checkedAt: formatTime(),
    source: "Démonstration locale",
    disclaimer: "MODE DÉMO : aucun service WhatsApp n'a été interrogé. Ce résultat ne signifie ni que le numéro est banni, ni qu'il ne l'est pas. Connectez une API autorisée pour obtenir des données réelles."
  };
}

/*
 * API integration example:
 *
 * async function fetchProviderResult(phone) {
 *   const response = await fetch("https://YOUR-OWN-SERVER.example/api/check", {
 *     method: "POST",
 *     headers: { "Content-Type": "application/json" },
 *     body: JSON.stringify({ phone })
 *   });
 *   if (!response.ok) throw new Error("Le fournisseur de données est indisponible.");
 *   const data = await response.json();
 *   // Validate the response schema before displaying it.
 *   // Return unknown when the provider has no reliable result.
 *   return {
 *     phone,
 *     status: data.banStatus === "banned" ? "banned" :
 *             data.banStatus === "not_banned" ? "not_banned" : "unknown",
 *     statusLabel: data.banStatus || "UNKNOWN",
 *     summary: data.summary || "Statut selon le fournisseur",
 *     spamReports: Number.isFinite(data.spamReports) ? String(data.spamReports) : "Inconnu",
 *     banStatus: data.banStatus || "Inconnu",
 *     reason: data.reason || "Non communiqué",
 *     checkedAt: formatTime(),
 *     source: data.sourceName || "API connectée",
 *     disclaimer: "Résultat fourni par la source indiquée. Vérifiez ses méthodes et sa fiabilité."
 *   };
 * }
 *
 * Do not call private or undocumented WhatsApp endpoints, scrape accounts,
 * or expose provider secrets in this client-side code.
 */

function addHistory(result) {
  const history = getHistory();
  const item = {
    phone: result.phone,
    statusLabel: result.statusLabel,
    checkedAt: result.checkedAt
  };
  saveHistory([item, ...history.filter(entry => entry.phone !== item.phone)]);
  renderHistory();
}

function renderHistory() {
  const items = getHistory();
  historyList.replaceChildren();
  historyEmpty.hidden = items.length > 0;
  clearHistoryButton.disabled = items.length === 0;

  for (const item of items) {
    const li = document.createElement("li");
    li.className = "history-item";

    const left = document.createElement("div");
    const number = document.createElement("div");
    number.className = "history-number";
    number.textContent = item.phone;
    const meta = document.createElement("div");
    meta.className = "history-meta";
    meta.textContent = item.checkedAt;
    left.append(number, meta);

    const status = document.createElement("div");
    status.className = "history-status";
    status.textContent = item.statusLabel;

    li.append(left, status);
    historyList.append(li);
  }
}

function checkNumber(raw) {
  hideError();
  const phone = normalizePhone(raw);
  if (!phone) {
    showError("Entrez un numéro au format international, avec + et 7 à 15 chiffres (ex. +33612345678).");
    phoneInput.focus();
    return;
  }

  // Demo mode by design: no fabricated ban or spam claims.
  const result = makeDemoResult(phone);
  renderResult(result);
  addHistory(result);
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  checkNumber(phoneInput.value);
});

document.querySelector("#demo-button").addEventListener("click", () => {
  phoneInput.value = "+33612345678";
  checkNumber(phoneInput.value);
});

document.querySelector("#check-another").addEventListener("click", () => {
  resultSection.hidden = true;
  phoneInput.value = "";
  phoneInput.focus();
  document.querySelector("#checker-title").scrollIntoView({ behavior: "smooth", block: "start" });
});

clearHistoryButton.addEventListener("click", () => {
  saveHistory([]);
  renderHistory();
});

renderHistory();
